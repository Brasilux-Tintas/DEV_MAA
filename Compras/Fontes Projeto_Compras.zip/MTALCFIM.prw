#include "totvs.ch"
#INCLUDE 'RWMAKE.CH'
#INCLUDE 'TBICONN.CH'
#INCLUDE 'PROTHEUS.CH'
#INCLUDE 'FWMVCDEF.CH'
#INCLUDE 'TOPCONN.CH'

/*/{Protheus.doc} MTALCFIM
Rotina automatica para aprovar pedidos de compra que tenham como origem SC de Ponto de Pedido (MATA170)
@type function Processamento
@version  1.00
@author marioantonaccio
@since 20/01/2026
@return character, sem retorno
@see
ParamIXB[1] = Array com informa��es do documento onde:
[1] [1] N�mero do documento
[1][2] Tipo de Documento
[1][3] Valor do Documento
[1][4] C�digo do Aprovador
[1][5] C�digo do Usu�rio
[1][6] Grupo do Aprovador
[1][7] Aprovador Superior
[1][8] Moeda do Documento
[1][9] Taxa da Moeda
[1][10] Data de Emiss�o do Documento
[1][11] Grupo de Compras

ParamIXB[3] = nOper (Opera��o a ser executada pela al�ada de aprova��o)
1 = Inclus�o do Documento
2 = Transfer�ncia da Al�ada para o Superior
3 = Exclus�o do documento
4 = Aprova��o do documento
5 = Estorno da Aprova��o
6 = Bloqueio manual
7 = Evento de rejei��o do documento
/*/

User function MTALCFIM()

    //   Local cDocSF1   := ParamIXB[4] // Chave(Alternativa) do SF1 para exclus�o SCR.
    //   Local lResiduo  := ParamIXB[5] // Elimina��o de Residuos.
    //  Local dDataRef  := ParamIXB[2] // Data de refer�ncia para o saldo.
    Local aArea   := FwGetArea() as Array
    Local aDocto  := ParamIXB[1] as Array // Array com informa��es do documento.
    Local aRegSCR := {}          as Array
    Local lRet    := .T.         as Logical
    Local nI                     as Numeric
    Local nOper   := ParamIXB[3] as Numeric // Opera��o a ser executada.

    //Cancelamento retorna o caminho original
    If nOper == 3
        Return(.T.)
    End

    //Aprova Automaticamente se a Solicitacao de Compra do Pedido for originaria de Ponto de Pedido (Rotina MATA170) - MAA 20260120
    SC7->(dbSetOrder(1))
    If SC7->(dbSeek(xFilial("SC7")+aDocto[1]))
        If .NOT. Empty(SC7->C7_NUMSC)
            SC1->(dbSetOrder(1))
            SC1->(dbSeek(xFilial("SC1")+SC7->C7_NUMSC+SC7->C7_ITEMSC))
            If .NOT. Upper(AllTrim(SC1->C1_ORIGEM)) == "MATA170" //Solicita�ao por ponto de pedido
                Return(.T.)
            End
        End
    else
         Return(.T.)    
    End

    //Fecha cursor se j� existir
    If Select("QRY_SCR") > 0
        QRY_SCR->(DbCloseArea())
    EndIf

    BeginSql Alias "QRY_SCR"
        SELECT
            R_E_C_N_O_ AS REGSCR
        FROM
            %TABLE:SCR% SCR
        WHERE
            SCR.%NOTDEL%
            AND SCR.CR_FILIAL = %XFILIAL:SCR%
            AND SCR.CR_STATUS IN ('01', '02')
            AND SCR.CR_TIPO IN ('IP', 'PC')
            AND SCR.CR_NUM = %EXP:aDocto[1]%
        ORDER BY
            SCR.CR_NIVEL
    EndSQL

    While .NOT. QRY_SCR->(EOF())
        AADD(aRegSCR,QRY_SCR->REGSCR)
        QRY_SCR->(dbSkip())
    End
    QRY_SCR->(dbCloseArea())

    For nI:=1 To Len(aRegSCR)

        SCR->(dbGoTo(aRegSCR[nI]))

        MaAlcDoc({ SCR->CR_NUM, SCR->CR_TIPO, , SCR->CR_APROV, , SCR->CR_GRUPO, , , , , }, dDataBase, 4)

        SCR->(dbGoto(aRegSCR[nI]))
        RecLock("SCR",.F.)
        SCR->CR_OBS := "Aprova��o Autom. por SC por Ponto Pedido"
        If SCR->(FieldPos("CR_AUTOMAT")) > 0
            SCR->CR_AUTOMAT := 'S'
        EndIf
        SCR->CR_DATALIB := Date()
        SCR->CR_USERLIB := "Autom."
        SCR->CR_LIBAPRO := "Autom."
        SCR->CR_TIPOLIM := ""
        MsUnlock()
    Next

    FwRestArea(aArea)

Return (lRet)
