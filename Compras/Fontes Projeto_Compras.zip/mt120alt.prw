#INCLUDE "TOTVS.CH"
/*/{Protheus.doc} MT120ALT
VAlida a Execu��o da rotina dentro do pedido de compras
@type function Telas
@version  1.0
@author marioantonaccio
@since 10/12/2025
@return logical, permite ou nao a execu��o da rotina
/*/
User Function MT120ALT()
    Local lExecuta := .T.

    If Paramixb[1] == 3  // Inclusao

        If SuperGetMV("BR_NINCPCM",.F.,.T.) .and.  FunName() <> "MATA122"
            FWAlertError("Inclusao de Pedido de Compra diretamente nao permitida!"+CRLF+CRLF+;
            "Utilize a "+"<b><u>"+" ROTINA DE COTA�AO (NFC)"+"</u></b>","Nao Permitida")
            lExecuta:=.F.
        End
    EndIf

    If Paramixb[1] == 4  // Altera��o
        dbSelectArea('SC7')
        If SC7->C7_TIPO == 1 .And. SC7->C7_CONAPRO == "L"
            If .NOT. FWAlertYesNo("Esse Pedido est� liberado!!!" + ;
                    CRLF+CRLF+"<b><u>"+"CASO HAJA ALTERA��O DE QUANTIDADE OU VALOR"+"</u></b>"+;
                    CRLF+" maior que "+cValToCHar(SuperGetMv("BR_TOLPRC",.F.,5))+" %"+;
                    CRLF+CRLF+"o mesmo retornarar� para "+"<b><u>"+"NOVA LIBERACAO"+"</u></b>"+;
                    CRLF+CRLF+"Deseja continuar comn a ALTERACAO ? ", "Alerta de Altera��o")
                lExecuta:=.F.
            End
        EndIf
    EndIf

Return( lExecuta )
