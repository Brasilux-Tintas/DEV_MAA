
/*
+------------------------------------------------------------------+
| SPEDMASTER_PRO.PRW                                               |
| Ferramenta de Auditoria e Correção SPED Fiscal                   |
| Versão: Teste Técnico                                            |
+------------------------------------------------------------------+
*/

#Include "protheus.ch"
#Include "fwmsg.ch"
#Include "topconn.ch"

//-------------------------------------------------------------------
User Function SPEDMASTER()

Local aMenu := {}

AAdd(aMenu,{"Processar SPED",{|| U_SPEDLOAD()}})
AAdd(aMenu,{"Auditoria Fiscal",{|| U_SPEDAUDIT()}})
AAdd(aMenu,{"Dashboard",{|| U_SPEDDASH()}})
AAdd(aMenu,{"Exportar Excel",{|| U_SPEDEXCEL()}})

FWMenu("SPED MASTER PRO",aMenu)

Return

//-------------------------------------------------------------------
User Function SPEDLOAD()

Local cEntrada := ""
Local cSaida
Local nIn
Local nOut
Local cLinha

cEntrada := cGetFile("SPED|*.txt","Selecione arquivo SPED")

If Empty(cEntrada)
   Return
EndIf

cSaida := FWFilePath(cEntrada)+FWFileName(cEntrada)+"_OK.txt"

nIn := FOpen(cEntrada)
nOut := FCreate(cSaida)

If nIn < 0
   MsgStop("Erro abrindo arquivo")
   Return
EndIf

While !FEOF(nIn)

   cLinha := FReadLine(nIn)

   If !Empty(cLinha)
      U_SPEDRULES(cLinha,nOut)
   EndIf

EndDo

FClose(nIn)
FClose(nOut)

MsgInfo("Processamento finalizado")

Return

//-------------------------------------------------------------------
Static Function SPEDRULES(cLinha,nOut)

Local a := StrTokArr(cLinha,"|")
Local cReg := ""

If Len(a) > 1
   cReg := a[2]
EndIf

Do Case

Case cReg == "C170"
   U_SPEDC170(@a)

Case cReg == "C190"
   U_SPEDC190(@a)

Case cReg == "D190"
   U_SPEDD190(@a)

Case cReg == "0206"
   U_SPEDBAR(@a)

EndCase

If Len(a) > 0
   FWrite(nOut,"|"+ArrayToStr(a,"|")+"|"+CRLF)
EndIf

Return

//-------------------------------------------------------------------
Static Function SPEDC170(a)

Local cCST := ""

If Len(a) >= 11
   cCST := AllTrim(a[11])
EndIf

If Len(cCST) == 2
   a[11] := "0"+cCST
EndIf

Return

//-------------------------------------------------------------------
Static oBar := Map():New()

Static Function SPEDBAR(a)

Local cBar := ""

If Len(a) >= 3
   cBar := a[3]
EndIf

If Empty(cBar)
   Return
EndIf

If oBar:HasKey(cBar)
   a := {}
Else
   oBar[cBar] := .T.
EndIf

Return

//-------------------------------------------------------------------
Static oD190 := Map():New()

Static Function SPEDD190(a)

Local cKey := ""
Local x

If Len(a) >= 5
   cKey := a[3]+"|"+a[4]+"|"+a[5]
EndIf

If !oD190:HasKey(cKey)

   oD190[cKey] := aClone(a)

Else

   x := oD190[cKey]

   If Len(x) >= 8 .and. Len(a) >= 8

      x[6] := Soma(x[6],a[6])
      x[7] := Soma(x[7],a[7])
      x[8] := Soma(x[8],a[8])

   EndIf

   oD190[cKey] := x

EndIf

Return

//-------------------------------------------------------------------
Static Function Soma(c1,c2)

Local n1 := Val(StrTran(c1,",","."))
Local n2 := Val(StrTran(c2,",","."))

Local n := n1+n2

Return Transform(n,"@E 9999999999.99")

//-------------------------------------------------------------------
Static oC190 := Map():New()

Static Function SPEDC190(a)

Local cKey := ""
Local x

If Len(a) >= 5
   cKey := a[3]+"|"+a[4]+"|"+a[5]
EndIf

If !oC190:HasKey(cKey)

   oC190[cKey] := aClone(a)

Else

   x := oC190[cKey]

   If Len(x) >= 8 .and. Len(a) >= 8

      x[6] := Soma(x[6],a[6])
      x[7] := Soma(x[7],a[7])
      x[8] := Soma(x[8],a[8])

   EndIf

   oC190[cKey] := x

EndIf

Return

//-------------------------------------------------------------------
User Function SPEDAUDIT()

Local aAudit := {}

AuditICMS(@aAudit)

If Len(aAudit) == 0
   MsgInfo("Nenhuma inconsistência encontrada")
Else
   FWBrowse(aAudit)
EndIf

Return

//-------------------------------------------------------------------
Static Function AuditICMS(aAudit)

Local nDif := 0

If nDif > 0
   AAdd(aAudit,{"ICMS divergente","C170 x C190"})
EndIf

Return

//-------------------------------------------------------------------
User Function SPEDDASH()

Local oDlg := MSDialog():New(0,0,500,400,"Dashboard Fiscal")

@20,20 SAY "SPED MASTER PRO"
@60,20 SAY "Ferramenta de auditoria SPED"

oDlg:Activate()

Return

//-------------------------------------------------------------------
User Function SPEDEXCEL()

Local oExcel := FWMsExcel():New()

oExcel:AddWorkSheet("Auditoria")

oExcel:AddRow({"Tipo","Descricao"})

oExcel:Activate()

Return

//-------------------------------------------------------------------
Static Function ArrayToStr(a,sep)

Local c := ""
Local n

For n := 1 To Len(a)

   If n == 1
      c := a[n]
   Else
      c += sep + a[n]
   EndIf

Next

Return c

