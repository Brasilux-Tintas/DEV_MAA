
/*
+------------------------------------------------------------------+
| SPEDMASTER_AUDIT.PRW                                             |
| Auditoria avançada SPED Fiscal                                   |
| Recursos                                                         |
| - Correção CST automática                                        |
| - Detecção inconsistências fiscais                               |
| - Log de alterações                                              |
| - Relatório Excel detalhado                                      |
+------------------------------------------------------------------+
*/

#Include "protheus.ch"
#Include "topconn.ch"
#Include "fwmsg.ch"

//------------------------------------------------------------------
// Estruturas globais
//------------------------------------------------------------------

Static aLogAlteracoes := {}
Static aInconsist     := {}
Static nLinhas        := 0
Static nCSTFix        := 0

//------------------------------------------------------------------
// MENU PRINCIPAL
//------------------------------------------------------------------

User Function SPEDAUDIT()

Local aMenu := {}

AAdd(aMenu,{"Processar SPED",{|| U_SPEDPROC()}})
AAdd(aMenu,{"Relatório Excel",{|| U_SPEDXLS()}})

FWMenu("SPED AUDITOR",aMenu)

Return

//------------------------------------------------------------------
// PROCESSAMENTO
//------------------------------------------------------------------

User Function SPEDPROC()

Local cArq := ""
Local nIn
Local cLinha
Local aCampos
Local cReg

cArq := cGetFile("SPED|*.txt","Selecione arquivo SPED")

If Empty(cArq)
   Return
EndIf

nIn := FOpen(cArq)

If nIn < 0
   MsgStop("Erro abrindo arquivo")
   Return
EndIf

While !FEOF(nIn)

   cLinha := FReadLine(nIn)

   If Empty(cLinha)
      Loop
   EndIf

   nLinhas++

   aCampos := StrTokArr(cLinha,"|")

   If Len(aCampos) > 1
      cReg := aCampos[2]
   Else
      cReg := ""
   EndIf

   Do Case

      Case cReg == "C170"
           U_FIXCST(@aCampos)
           U_AUDITC170(aCampos)

      Case cReg == "C190"
           U_AUDITC190(aCampos)

   EndCase

EndDo

FClose(nIn)

MsgInfo("Processamento concluído")

Return

//------------------------------------------------------------------
// CORREÇÃO CST
//------------------------------------------------------------------

Static Function FIXCST(a)

Local cCST

If Len(a) < 11
   Return
EndIf

cCST := AllTrim(a[11])

If Len(cCST) == 2

   AAdd(aLogAlteracoes,;
      {"C170","CST ajustado "+cCST+" -> 0"+cCST})

   a[11] := "0"+cCST

   nCSTFix++

EndIf

Return

//------------------------------------------------------------------
// AUDITORIA C170
//------------------------------------------------------------------

Static Function AUDITC170(a)

Local nValor := 0

If Len(a) >= 8
   nValor := Val(StrTran(a[8],",","."))
EndIf

If nValor < 0

   AAdd(aInconsist,;
      {"C170","Valor ICMS negativo",a[3]})

EndIf

Return

//------------------------------------------------------------------
// AUDITORIA C190
//------------------------------------------------------------------

Static Function AUDITC190(a)

Local nBase := 0

If Len(a) >= 7
   nBase := Val(StrTran(a[7],",","."))
EndIf

If nBase < 0

   AAdd(aInconsist,;
      {"C190","Base ICMS negativa",a[3]})

EndIf

Return

//------------------------------------------------------------------
// RELATÓRIO EXCEL
//------------------------------------------------------------------

User Function SPEDXLS()

Local oExcel := FWMsExcel():New()
Local n

oExcel:AddWorkSheet("Resumo")

oExcel:AddRow({"Indicador","Valor"})
oExcel:AddRow({"Linhas processadas",nLinhas})
oExcel:AddRow({"CST corrigidos",nCSTFix})

oExcel:AddWorkSheet("Alteracoes")

oExcel:AddRow({"Registro","Descricao"})

For n := 1 To Len(aLogAlteracoes)
   oExcel:AddRow(aLogAlteracoes[n])
Next

oExcel:AddWorkSheet("Inconsistencias")

oExcel:AddRow({"Registro","Descricao","Referencia"})

For n := 1 To Len(aInconsist)
   oExcel:AddRow(aInconsist[n])
Next

oExcel:Activate()

Return
