
/*
+------------------------------------------------------------------+
| SPEDMASTER_EXTREME.PRW                                           |
| Auditoria e Correção Avançada de SPED Fiscal                     |
| Versão: Consultoria / Testes                                     |
+------------------------------------------------------------------+
| Recursos                                                         |
| - Correção CST 2 -> 3 posições (C170)                            |
| - Consolidação C170 duplicado                                    |
| - Consolidação C190                                              |
| - Consolidação D190                                              |
| - Remoção duplicidade código de barras (0206)                    |
| - Recontagem bloco 9900 / 9999                                   |
| - Auditoria básica ICMS                                          |
| - Exportação Excel                                               |
| - Dashboard simples                                              |
+------------------------------------------------------------------+
*/

#Include "protheus.ch"
#Include "fwmsg.ch"
#Include "topconn.ch"

//------------------------------------------------------------------
// Variáveis globais de processamento
//------------------------------------------------------------------

Static oBarCodes := Map():New()
Static oC190     := Map():New()
Static oD190     := Map():New()
Static oC170     := Map():New()
Static o9900     := Map():New()

Static nLinhas   := 0
Static nC170Fix  := 0
Static nC170Dup  := 0
Static nC190Cons := 0
Static nD190Cons := 0
Static nBarDup   := 0

//------------------------------------------------------------------
// MENU PRINCIPAL
//------------------------------------------------------------------

User Function SPEDMASTER()

Local aMenu := {}

AAdd(aMenu,{"Processar SPED",{|| U_SPEDLOAD()}})
AAdd(aMenu,{"Auditoria Fiscal",{|| U_SPEDAUDIT()}})
AAdd(aMenu,{"Dashboard",{|| U_SPEDDASH()}})
AAdd(aMenu,{"Exportar Excel",{|| U_SPEDEXCEL()}})

FWMenu("SPED MASTER EXTREME",aMenu)

Return

//------------------------------------------------------------------
// LEITURA DO SPED
//------------------------------------------------------------------

User Function SPEDLOAD()

Local cEntrada := ""
Local cSaida
Local nIn
Local nOut
Local cLinha

cEntrada := cGetFile("SPED|*.txt","Selecione arquivo SPED")

If Empty(cEntrada)
   Return
EndIf

cSaida := FWFilePath(cEntrada)+FWFileName(cEntrada)+"_CORRIGIDO.txt"

nIn := FOpen(cEntrada)
nOut := FCreate(cSaida)

If nIn < 0
   MsgStop("Erro abrindo arquivo SPED")
   Return
EndIf

While !FEOF(nIn)

   cLinha := FReadLine(nIn)

   If !Empty(cLinha)

      nLinhas++
      U_SPEDRULES(cLinha,nOut)

   EndIf

EndDo

U_SPED9900(nOut)

FClose(nIn)
FClose(nOut)

MsgInfo("Processamento concluído")

Return

//------------------------------------------------------------------
// MOTOR DE REGRAS
//------------------------------------------------------------------

Static Function SPEDRULES(cLinha,nOut)

Local aCampos := StrTokArr(cLinha,"|")
Local cReg    := ""

If Len(aCampos) > 1
   cReg := aCampos[2]
EndIf

U_COUNTREG(cReg)

Do Case

Case cReg == "C170"
   U_SPEDC170(@aCampos)

Case cReg == "C190"
   U_SPEDC190(@aCampos)

Case cReg == "D190"
   U_SPEDD190(@aCampos)

Case cReg == "0206"
   U_SPEDBAR(@aCampos)

EndCase

If Len(aCampos) > 0
   FWrite(nOut,"|"+U_ARRAY2STR(aCampos,"|")+"|"+CRLF)
EndIf

Return

//------------------------------------------------------------------
// CORREÇÃO CST C170
//------------------------------------------------------------------

Static Function SPEDC170(a)

Local cCST := ""
Local cKey := ""

If Len(a) >= 11
   cCST := AllTrim(a[11])
EndIf

If Len(cCST) == 2
   a[11] := "0"+cCST
   nC170Fix++
EndIf

cKey := a[3]+"|"+a[4]+"|"+a[11]

If oC170:HasKey(cKey)

   nC170Dup++
   a := {}

Else

   oC170[cKey] := .T.

EndIf

Return

//------------------------------------------------------------------
// CONSOLIDAÇÃO C190
//------------------------------------------------------------------

Static Function SPEDC190(a)

Local cKey := ""
Local aOld

If Len(a) >= 5
   cKey := a[3]+"|"+a[4]+"|"+a[5]
EndIf

If !oC190:HasKey(cKey)

   oC190[cKey] := aClone(a)

Else

   aOld := oC190[cKey]

   aOld[6] := U_SOMA(aOld[6],a[6])
   aOld[7] := U_SOMA(aOld[7],a[7])
   aOld[8] := U_SOMA(aOld[8],a[8])

   oC190[cKey] := aOld
   nC190Cons++

EndIf

Return

//------------------------------------------------------------------
// CONSOLIDAÇÃO D190
//------------------------------------------------------------------

Static Function SPEDD190(a)

Local cKey := ""
Local aOld

If Len(a) >= 5
   cKey := a[3]+"|"+a[4]+"|"+a[5]
EndIf

If !oD190:HasKey(cKey)

   oD190[cKey] := aClone(a)

Else

   aOld := oD190[cKey]

   aOld[6] := U_SOMA(aOld[6],a[6])
   aOld[7] := U_SOMA(aOld[7],a[7])
   aOld[8] := U_SOMA(aOld[8],a[8])

   oD190[cKey] := aOld
   nD190Cons++

EndIf

Return

//------------------------------------------------------------------
// REMOÇÃO CODIGO BARRAS DUPLICADO
//------------------------------------------------------------------

Static Function SPEDBAR(a)

Local cBar := ""

If Len(a) >= 3
   cBar := a[3]
EndIf

If Empty(cBar)
   Return
EndIf

If oBarCodes:HasKey(cBar)

   nBarDup++
   a := {}

Else

   oBarCodes[cBar] := .T.

EndIf

Return

//------------------------------------------------------------------
// CONTADOR BLOCO 9900
//------------------------------------------------------------------

Static Function COUNTREG(cReg)

If Empty(cReg)
   Return
EndIf

If !o9900:HasKey(cReg)
   o9900[cReg] := 1
Else
   o9900[cReg]++
EndIf

Return

//------------------------------------------------------------------
// GRAVA BLOCO 9900
//------------------------------------------------------------------

Static Function SPED9900(nOut)

Local cKey

For Each cKey In o9900

   FWrite(nOut,"|9900|"+cKey+"|"+;
      cValToChar(o9900[cKey])+"|"+CRLF)

Next

FWrite(nOut,"|9990|"+cValToChar(Len(o9900)+1)+"|"+CRLF)
FWrite(nOut,"|9999|"+cValToChar(nLinhas)+"|"+CRLF)

Return

//------------------------------------------------------------------
// AUDITORIA ICMS
//------------------------------------------------------------------

User Function SPEDAUDIT()

Local aAudit := {}

If nC170Fix > 0
   AAdd(aAudit,{"C170 CST corrigido",cValToChar(nC170Fix)})
EndIf

If nC170Dup > 0
   AAdd(aAudit,{"C170 duplicado removido",cValToChar(nC170Dup)})
EndIf

If nBarDup > 0
   AAdd(aAudit,{"Código barras duplicado",cValToChar(nBarDup)})
EndIf

If Len(aAudit) == 0
   MsgInfo("Nenhuma inconsistência encontrada")
Else
   FWBrowse(aAudit)
EndIf

Return

//------------------------------------------------------------------
// DASHBOARD
//------------------------------------------------------------------

User Function SPEDDASH()

Local oDlg := MSDialog():New(0,0,500,300,"Dashboard Fiscal")

@20,20 SAY "SPED MASTER EXTREME"
@60,20 SAY "Linhas processadas: "+cValToChar(nLinhas)
@80,20 SAY "C170 corrigidos: "+cValToChar(nC170Fix)
@100,20 SAY "C170 duplicados: "+cValToChar(nC170Dup)
@120,20 SAY "C190 consolidados: "+cValToChar(nC190Cons)
@140,20 SAY "D190 consolidados: "+cValToChar(nD190Cons)

oDlg:Activate()

Return

//------------------------------------------------------------------
// EXPORTAÇÃO EXCEL
//------------------------------------------------------------------

User Function SPEDEXCEL()

Local oExcel := FWMsExcel():New()

oExcel:AddWorkSheet("Resumo")

oExcel:AddRow({"Indicador","Valor"})
oExcel:AddRow({"Linhas",nLinhas})
oExcel:AddRow({"C170 corrigidos",nC170Fix})
oExcel:AddRow({"C170 duplicados",nC170Dup})
oExcel:AddRow({"C190 consolidados",nC190Cons})
oExcel:AddRow({"D190 consolidados",nD190Cons})

oExcel:Activate()

Return

//------------------------------------------------------------------
// FUNÇÃO SOMA DECIMAL
//------------------------------------------------------------------

Static Function SOMA(c1,c2)

Local n1 := Val(StrTran(c1,",","."))
Local n2 := Val(StrTran(c2,",","."))

Local n := n1+n2

Return Transform(n,"@E 9999999999.99")

//------------------------------------------------------------------
// ARRAY -> STRING
//------------------------------------------------------------------

Static Function ARRAY2STR(a,sep)

Local c := ""
Local n

For n := 1 To Len(a)

   If n == 1
      c := a[n]
   Else
      c += sep + a[n]
   EndIf

Next

Return c
